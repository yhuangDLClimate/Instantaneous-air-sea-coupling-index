function [d1,theta]=dynamical_parameters(Field)

%--- Field: 3-D data (lon/lat/time)

if ndims(Field)==3
   [a,b,c]=size(Field);
   Field=reshape(Field,a*b,c);
end


quanti=0.98;%quantle for extreme

%parfor i=1:size(Field,2) % if you have several cpus, just switch on "parfor" here
for i=1:size(Field,2)
    %Apply the logarithm to the distances
    field0=Field(:,i);
     distance = zeros(size(Field,2) ,1);
    for k=1:size(Field,2)  
        field=Field(:,k);
        distance(k)=sqrt(nansum(((field0-field).^2)));  %'euclidean distance'
    end
        
    logdista0=-log(distance);
   % extreme
    thresh=quantile(logdista0, quanti);
    
    logdista=sort(logdista0);   % 
    findidx=find(logdista> thresh,1);
    logextr=logdista(findidx:end-1);
    logextr(isinf(logextr)==1)=[];
    lambda=std(logextr);
    d1(i)=1/(lambda);

    
    theta(i)=extremal_Sueveges(logdista0,quanti);
    
    
end

d1=d1';% Instantaneous dimension
theta=theta'; % Instantaneous persistence

end


function [theta]=extremal_Sueveges(Y,p)
u=quantile(Y, p);
q=1-p;
Li=find(Y>u);
Ti=diff(Li);
Si=Ti-1;
Nc=length(find(Si>0));
N=length(Ti);
theta=(sum(q.*Si)+N+Nc- sqrt( (sum(q.*Si) +N+Nc).^2 -8*Nc*sum(q.*Si)) )./(2*sum(q.*Si));
end

