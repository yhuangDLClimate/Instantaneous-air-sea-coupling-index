clear;clc;

%% plotting the spatial field
load('demo_data.mat');%the SST and SAT anomaly data for demonstration 

figure(1)
[L1,L2]=meshgrid(lon,lat);
[L1sst,L2sst]=meshgrid(lonsst,latsst);

subplot(2,1,1)
m_proj('miller','long',[-80 48],'lat',[25 70]);
m_contourf(L1',L2',mean(dsat(:,:,1),3),'linestyle','none');colorbar;caxis([-5,5]);
hold on;
m_coast('linewidth',1,'color','k');
m_grid('ytick',[30,45,60],'linestyle','none');
title('SAT anomaly at a certain day/��');
xlabel('longitude');ylabel('latitude');

subplot(2,1,2)
m_proj('miller','long',[-80 48],'lat',[25 70]);
m_contourf(L1sst',L2sst',mean(dsst(:,:,1),3),'linestyle','none');colorbar;caxis([-5,5]);
hold on;m_coast('linewidth',1,'color','k');
m_grid('ytick',[30,45,60],'linestyle','none');
title('SST anomaly at a certain day/��');
xlabel('longitude');ylabel('latitude');


%% plot the dimension, persistence, and air-sea coupling strengths 
figure(2)
load('demo_dsm_calculatedresult.mat');%the resultdata is computed through the lines below, I just pre-saved it here.
scatter(d_sat,theta_sat,20,alpha_sst_sat,'filled');
xlabel('local dimension_{SAT anomaly}');ylabel('inverse of persistence_{SAT anomaly}');
colormap('hot');h1=colorbar;set(get(h1,'Title'),'string','coupling index');


%% calculation demonstration
[d_sat,theta_sat]=dynamical_parameters(dsat); % instantaneous dimension: d, inverse of persistence: theta
[alpha_sst_sat]=co_recurrence(dsat,dsst);% instantaneous coupling strength: alpha
% if you have sevral cpus to conduct paraller computations in MATLAB,
% you may switch on "parfor" inside the scripts "dynamical_parameters" and "co_recurrence" 
% it's better for DSM to use "parfor" to accelarate the computation. 




