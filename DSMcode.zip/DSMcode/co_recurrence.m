function [alpha]=co_recurrence(Fieldx,Fieldy)

%--- Field: 3-D data (lon/lat/time)
if ndims(Fieldx)==3
   [a,b,c]=size(Fieldx);
   Fieldx=reshape(Fieldx,a*b,c);
end

if ndims(Fieldy)==3
[a,b,c]=size(Fieldy);
Fieldy=reshape(Fieldy,a*b,c);
end

quanti=0.98;%quantle for extreme
sizex=std(sqrt(nansum(Fieldx.^2)));
Fieldx=Fieldx/sizex;
sizey=std(sqrt(nansum(Fieldy.^2)));
Fieldy=Fieldy/sizey;

%parfor i=1:size(Fieldx,2) % if you have several cpus, just switch on "parfor" here
for i=1:size(Fieldx,2)
    %Apply the logarithm to the distances
    fieldx0=Fieldx(:,i);
    distancex = zeros(size(Fieldx,2) ,1);
    
    fieldy0=Fieldy(:,i);
    distancey = zeros(size(Fieldy,2) ,1);
    
    for k=1:size(Fieldx,2)  
        fx=Fieldx(:,k);
        distancex(k)=sqrt(nansum(((fieldx0-fx).^2)));  % 'euclidean distance'
        
        fy=Fieldy(:,k);
        distancey(k)=sqrt(nansum(((fieldy0-fy).^2))); 
    end
        
    logdistax0=-log(distancex);
    logdistay0=-log(distancey);
    
   % threshold
    threshx=quantile(logdistax0, quanti);
    threshy=quantile(logdistay0, quanti);

   %alpha
    Positionx=find(logdistax0 > threshx);
    Positiony=find(logdistay0 > threshy);
    
    mu_xy=length(intersect(Positionx,Positiony));
    mu_x=length(Positionx);
    alpha(i)=mu_xy/mu_x;    
end


end

